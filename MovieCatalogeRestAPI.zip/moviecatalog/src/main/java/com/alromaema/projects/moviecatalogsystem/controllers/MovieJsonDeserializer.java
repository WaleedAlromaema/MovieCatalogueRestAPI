package com.alromaema.projects.moviecatalogsystem.controllers;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import java.text.ParseException;

import com.alromaema.projects.moviecatalogsystem.domain.Actor;
import com.alromaema.projects.moviecatalogsystem.domain.Director;
import com.alromaema.projects.moviecatalogsystem.domain.Movie;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
/**
 *  Deserializer Object from Jackson Object to Movie class
 *
 * @author Waleed Alromaema
 */

public class MovieJsonDeserializer extends StdDeserializer<Movie> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MovieJsonDeserializer(){
		this(null);
	}

	public MovieJsonDeserializer(Class<Movie> t) {
		super(t);
	}

	@Override
	public Movie deserialize(JsonParser parser, DeserializationContext context) throws IOException, JsonProcessingException {
		JsonNode node = parser.getCodec().readTree(parser);
		
		Movie movie = new Movie();
		Set<Actor> actors= new HashSet<>();
		Set<Director> directors= new HashSet<>();
		
		
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		
		JsonNode actor_node = node.get("Actors");
		JsonNode director_node = node.get("Directors");
		System.out.println("Actors node==: "+actor_node);
		System.out.println("Directors node==: "+director_node);
		
		if(actor_node!=null)
		{ System.out.println("actor_node.size() ="+actor_node.size());
		for(int i=0;i<actor_node.size();i++)
		{
		        Actor a =new Actor();
		        
		        if(!node.hasNonNull("id") && (actor_node.get(i).get("id")!=null))
		        {
		        a.setId(actor_node.get(i).get("id").asInt()); 
		        }
		        if(!node.hasNonNull("FIRST_NAME")&& (actor_node.get(i).get("FIRST_NAME")!=null))
		        {
		        	 a.setFirstName(actor_node.get(i).get("FIRST_NAME").asText());
		        }
		        if(!node.hasNonNull("LAST_NAME")&& (actor_node.get(i).get("LAST_NAME")!=null))
		        {
		        	a.setLastName(actor_node.get(i).get("LAST_NAME").asText());
		        }
		        if(!node.hasNonNull("NUMBER_MOVIES")&& (actor_node.get(i).get("NUMBER_MOVIES")!=null))
		        {
		        	a.setNumber_movies(actor_node.get(i).get("NUMBER_MOVIES").asInt());
		        }
		        if(!node.hasNonNull("NATIONALITY")&& (actor_node.get(i).get("NATIONALITY")!=null))
		        {
		        	a.setNationality(actor_node.get(i).get("NATIONALITY").asText());	   
		        }
		        if(!node.hasNonNull("GANDER")&& (actor_node.get(i).get("GANDER")!=null))
		        {
		        	a.setGander(actor_node.get(i).get("GANDER").asText());
		        }
		        if(!node.hasNonNull("START_YEAR")&& (actor_node.get(i).get("START_YEAR")!=null))
		        {
		        	String sy=actor_node.get(i).get("START_YEAR").asText();
				try {
					 a.setStartYear(formatter.parse(sy));
				} catch (ParseException e) {
					e.printStackTrace();
					throw new IOException(e);
				}
		        }
		        if(!node.hasNonNull("BIRTH_DATE")&& (actor_node.get(i).get("BIRTH_DATE")!=null))
		        {
		        	String bd=actor_node.get(i).get("BIRTH_DATE").asText();
				try {
					 a.setBirthDate(formatter.parse(bd));
				} catch (ParseException e) {
					e.printStackTrace();
					throw new IOException(e);
				}
		        }
				
				actors.add(a);
				 System.out.println("Actor["+i+"] is="+a);
			     	
		     		}
		} else {System.out.println("the actor node is null");}
		if(director_node!=null)
		{
		for(int i=0;i<director_node.size();i++)
		{
		        Director a =new Director();
		        if(!node.hasNonNull("id") && (director_node.get(i).get("id")!=null))
		        {
		        a.setId(director_node.get(i).get("id").asInt()); 
		        }
		        if(!node.hasNonNull("FIRST_NAME")&& (director_node.get(i).get("FIRST_NAME")!=null))
		        {
		        	 a.setFirstName(director_node.get(i).get("FIRST_NAME").asText());
		        }
		        if(!node.hasNonNull("LAST_NAME")&& (director_node.get(i).get("LAST_NAME")!=null))
		        {
		        	a.setLastName(director_node.get(i).get("LAST_NAME").asText());
		        }
		        if(!node.hasNonNull("NUMBER_DIRECTED_MOVIES")&& (director_node.get(i).get("NUMBER_DIRECTED_MOVIES")!=null))
		        {
		        	a.setNumber_directed_movies(director_node.get(i).get("NUMBER_DIRECTED_MOVIES").asInt());
		        }
		        if(!node.hasNonNull("NATIONALITY")&& (director_node.get(i).get("NATIONALITY")!=null))
		        {
		        	a.setNationality(director_node.get(i).get("NATIONALITY").asText());	   
		        }
		        if(!node.hasNonNull("GANDER")&& (director_node.get(i).get("GANDER")!=null))
		        {
		        	a.setGander(director_node.get(i).get("GANDER").asText());
		        }
		        if(!node.hasNonNull("START_YEAR")&& (director_node.get(i).get("START_YEAR")!=null))
		        {
		        	String sy=director_node.get(i).get("START_YEAR").asText();
				try {
					 a.setStartYear(formatter.parse(sy));
				} catch (ParseException e) {
					e.printStackTrace();
					throw new IOException(e);
				}
		        }
		        if(!node.hasNonNull("BIRTH_DATE")&& (director_node.get(i).get("BIRTH_DATE")!=null))
		        {
		        	String bd=director_node.get(i).get("BIRTH_DATE").asText();
				try {
					 a.setBirthDate(formatter.parse(bd));
				} catch (ParseException e) {
					e.printStackTrace();
					throw new IOException(e);
				}
		        }
		        
				directors.add(a);
		        System.out.println("Director["+i+"] is="+a);
		     		}
		
		}else {System.out.println("the director node is null");}
		String TITEL = node.get("TITEL").asText(null);
		Date MOVIE_YEAR=null;
		
		String startYearStr=node.get("MOVIE_YEAR").asText(null);
		try {
			MOVIE_YEAR = formatter.parse(startYearStr);
		} catch (ParseException e) {
			e.printStackTrace();
			throw new IOException(e);
		}
		String GENRE = node.get("GENRE").asText(null);
		Integer RATING = node.get("RATING").asInt();
		if (node.hasNonNull("id")) {
			movie.setId(node.get("ID").asInt());
		}
        movie.setTitel(TITEL);
        movie.setGenre(GENRE);
        movie.setRating(RATING);
        movie.setMovie_year(MOVIE_YEAR);
        movie.setActors(actors);
        movie.setDirectors(directors);
        
      return movie;
	}
	
}